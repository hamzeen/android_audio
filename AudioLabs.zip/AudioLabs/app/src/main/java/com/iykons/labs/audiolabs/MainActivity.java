package com.iykons.labs.audiolabs;

import android.content.Intent;
import android.media.MediaRecorder;
import android.os.Environment;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


public class MainActivity extends ActionBarActivity {
    private static final String APP_TAG = "com.iykons.labs";
    private MediaRecorder recorder;
    private boolean recording = false;

    private Button btnNew;
    Toast toast = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnNew = (Button) findViewById(R.id.btnNew);
        btnNew.setOnClickListener(newRecordListener);

        buildListView();
    }

    /**
     * Retrieve data on onResume Activity Cicle Life state in order to refresh data
     */
    @Override
    protected void onResume() {
        super.onResume();
        showToast("Resuming...");
        buildListView();
    }

    @Override
    public void onPause() {
        super.onPause();

        btnNew.setText("Record");
        if (recorder != null) {
            recorder.release();
            recorder = null;
        }
    }

    private void buildListView(){
        List<String> fileList = getFileNames();
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
                R.layout.audioclip_list, fileList);
        ListView listView = (ListView) findViewById(R.id.listView1);

        listView.setAdapter(dataAdapter);
        listView.setTextFilterEnabled(true);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                final String temp = (String) parent.getItemAtPosition(position);

                Intent intent = new Intent(MainActivity.this, PreviewAudio.class);
                intent.putExtra("filename", temp);
                MainActivity.this.startActivity(intent);
            }
        });
    }

    private final View.OnClickListener newRecordListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            if (!recording) {
                showToast("Recording Started.");
                startRecording();

                btnNew.setText("Stop");
            } else {
                stopRecording();

                btnNew.setText("Record");
                showToast("Recording Finished.");
            }
        }
    };

    /**
     * Starts Recording.
     */
    private void startRecording(){
        Log.d(APP_TAG, "start recording..");

        recorder = new MediaRecorder();
        recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        recorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);

        SimpleDateFormat timeStampFormat = new SimpleDateFormat(
                "yyyy-MM-dd-HH.mm.ss");
        String fileName = "Audio_" + timeStampFormat.format(new Date());

        String temp = Environment.getExternalStorageDirectory().getAbsolutePath(); //--> "/storage/sdcard0"
        File audioClipDir = new File(temp+"/iykons");
        if (!audioClipDir.exists()) {
            audioClipDir.mkdirs();
        }

        recorder.setOutputFile(audioClipDir.getAbsolutePath() +"/"+ fileName + ".3gp");
        recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);

        try {
            recorder.prepare();
        } catch (IOException e) {
            Log.e(APP_TAG, "prepare() failed");
        }

        recording = true;
        recorder.start();
    }

    private void stopRecording() {
        recorder.stop();
        recorder.release();

        recording = false;
        buildListView();
        recorder = null;
    }

    public List<String> getFileNames() {
        List<String> list = new ArrayList<String>(20);
        File sdCardRoot = Environment.getExternalStorageDirectory();
        File yourDir = new File(sdCardRoot, "/iykons");
        for (File f : yourDir.listFiles()) {
            if (f.isFile())
                list.add(f.getName());
        }
        return list;
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            showToast("A lab application by iykons.");
        }

        return super.onOptionsItemSelected(item);
    }

    private void showToast(String message){
        toast = Toast.makeText(getApplicationContext(),message, Toast.LENGTH_SHORT);
        toast.setGravity(Gravity.TOP, 25, 300);
        toast.show();
    }
}
