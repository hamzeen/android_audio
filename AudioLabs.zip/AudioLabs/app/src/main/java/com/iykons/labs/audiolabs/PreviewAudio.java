package com.iykons.labs.audiolabs;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;

/**
 * Created by admin on 4/17/15.
 */
public class PreviewAudio extends Activity{
    private static final String APP_TAG = "com.iykons.labs";
    String filename = null;
    private TextView txtFileName;
    private Button btnDiscard,btnTogglePlay;

    private MediaPlayer player = null;
    private boolean playing = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.preview_audio);

        Bundle bundle = getIntent().getExtras();
        filename = bundle.getString("filename");

        txtFileName = (TextView) findViewById(R.id.txt);
        txtFileName.setText(filename);

        btnTogglePlay = (Button) findViewById(R.id.playpause);
        btnTogglePlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (playing) { //play or pause
                    stopPlaying();
                } else {
                    startPlaying();
                }
            }
        });

        btnDiscard = (Button) findViewById(R.id.delete);
        btnDiscard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteFile(new File(getDir()+"/"+PreviewAudio.this.filename));

                Intent intent = new Intent(PreviewAudio.this, MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });
    }

    private void startPlaying() {
        player = new MediaPlayer();
        try {
            player.setDataSource(getDir() + "/" + this.filename);
            player.prepare();
            player.start();
        } catch (IOException e) {
            Log.e(APP_TAG, "prepare() failed");
        }
    }

    private void stopPlaying() {
        player.release();
        player = null;
    }

    public boolean deleteFile(File file) {
        return file.delete();
    }

    public String getDir(){
        String temp = Environment.getExternalStorageDirectory().getAbsolutePath(); //--> "/storage/sdcard0"
        return temp +"/iykons";
    }

    @Override
    public void onPause() {
        super.onPause();
        if (player != null) {
            player.release();
            player = null;
        }
    }
}
